import { initializeApp, getApp, getApps } from 'firebase/app';
import {
  initializeAuth,
  getAuth,
  getReactNativePersistence
} from 'firebase/auth';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getFirestore } from 'firebase/firestore';

// CodeQuest Firebase project configuration
const firebaseConfig = {
  projectId: "codequest-435cf",
  storageBucket: "codequest-435cf.firebasestorage.app"
};

const app = getApps().length ? getApp() : initializeApp(firebaseConfig);

let auth;
try {
  auth = initializeAuth(app, {
    persistence: getReactNativePersistence(AsyncStorage)
  });
} catch (error) {
  // Auth may already have been initialized during Fast Refresh.
  auth = getAuth(app);
}

const db = getFirestore(app);

export { app, auth, db };
